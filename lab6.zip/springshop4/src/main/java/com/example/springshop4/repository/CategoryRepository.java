package com.example.springshop4.repository;

import com.example.springshop4.model.category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<category,Integer> {
}
