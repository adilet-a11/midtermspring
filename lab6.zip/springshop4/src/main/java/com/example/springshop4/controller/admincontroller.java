package com.example.springshop4.controller;

import com.example.springshop4.dto.ProductDTO;
import com.example.springshop4.model.category;
import com.example.springshop4.model.product;
import com.example.springshop4.repository.CategoryRepository;
import com.example.springshop4.service.CategoryService;
import com.example.springshop4.service.Productservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

@Controller
public class admincontroller {
    public static String uploadDir = System.getProperty("user.dir") + "/src/main/resources/static/productImages";
    @Autowired
    CategoryService categoryService;

    @Autowired
    Productservice productservice;

    @Autowired
    CategoryRepository categoryRepository;
    @GetMapping()
    public String adminHome(){
        return "adminHome";
    }

    @GetMapping("/admin/categories")
    public String getCategory(Model model) {
        model.addAttribute("categories", categoryService.getallcategory());
        return "categories";
    }

    @GetMapping("/admin/categories/add")
    public String addCategory(Model model) {
        model.addAttribute("category", new category());
        return "categoriesAdd";
    }

    @PostMapping("/admin/categories/add")
    public String postCategory(@ModelAttribute("category") category category) {
        categoryService.addCategory(category);
        return "redirect:/admin/categories";
    }

    @GetMapping("/admin/categories/delete/{id}")
    public String deleteCategory(@PathVariable int id) {
        categoryService.removeCategoryById(id);

        return "redirect:/admin/categories";
    }

    @GetMapping("/admin/categories/update/{id}")
    public String updateCategory(@PathVariable int id, Model model) {
        Optional<category> category = categoryService.getcategoryById(id);
        if (category.isPresent()) {
            model.addAttribute("category", category.get());
            return "categoriesAdd";
        } else
            return "404";
    }

    @GetMapping("/admin/products")
    public String products(Model model) {
        model.addAttribute("products", productservice.getallProduct());
        return "products";
    }

    @GetMapping("/admin/products/add")
    public String productsaddGet(Model model) {
        model.addAttribute("productdto", new ProductDTO());
        List<category>categories=categoryService.getallcategory();
        model.addAttribute("categories", categories);
        return "productsAdd";
    }

    @PostMapping("/admin/products/add")
    public String productaddPost(@ModelAttribute("productdto") ProductDTO productdto,
                                 @RequestParam("productImage") MultipartFile file,
                                 @RequestParam("imgName") String imgName) throws IOException {
        product product = new product();
        product.setId(productdto.getId());
        product.setName(productdto.getName());
        product.setCategory(categoryRepository.findById(productdto.getCategoryId()).get());
        product.setPrice(productdto.getPrice());
        product.setWeight(productdto.getWeight());
        product.setDescription(productdto.getDescription());

        String imageUUID    ;
        if(!file.isEmpty()){
            imageUUID = file.getOriginalFilename();
            Path fileNameandPath = Paths.get(uploadDir,imageUUID);
            Files.write(fileNameandPath,file.getBytes());
        }else {
            imageUUID=imgName;
        }
        product.setImageName(imageUUID);
        productservice.addProduct(product);
        return "redirect:/admin/products";
    }

    @GetMapping("/admin/product/delete/{id}")
    public String deleteProduct(@PathVariable long id){
        productservice.removeproductbyid(id);
        return "redirect:/admin/products";
    }

    @GetMapping("/admin/product/update/{id}")
    public String updateProduct(@PathVariable long id,Model model){
        product product = productservice.getproductbyid(id).get();
        ProductDTO productDTO = new ProductDTO();
        productDTO.setId(product.getId());
        productDTO.setName(product.getName());
        productDTO.setCategoryId(product.getCategory().getId());
        productDTO.setPrice(product.getPrice());
        productDTO.setDescription(product.getDescription());
        productDTO.setImageName(product.getImageName());

        model.addAttribute("categories",categoryService.getallcategory());
        model.addAttribute("productdto",productDTO);
        return "productsAdd";
    }


}

