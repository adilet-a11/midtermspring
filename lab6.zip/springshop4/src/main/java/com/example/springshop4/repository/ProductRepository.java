package com.example.springshop4.repository;

import com.example.springshop4.model.product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepository extends JpaRepository<product,Long> {

    List<product> findAllByCategoryId(int id);
}
