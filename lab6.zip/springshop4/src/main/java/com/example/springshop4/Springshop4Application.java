package com.example.springshop4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springshop4Application {

    public static void main(String[] args) {
        SpringApplication.run(Springshop4Application.class, args);
    }

}
