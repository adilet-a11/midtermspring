package com.example.springshop4.service;

import com.example.springshop4.model.category;
import com.example.springshop4.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoryService {
@Autowired
//static

CategoryRepository categoryRepository;

    public List<category> getallcategory(){
        return categoryRepository.findAll();
    }
    public void addCategory(category category){
        categoryRepository.save(category);
    }

    public void removeCategoryById(int id){
        categoryRepository.deleteById(id);
    }

    public Optional<category> getcategoryById(int id){
        return categoryRepository.findById(id);
    }


}
