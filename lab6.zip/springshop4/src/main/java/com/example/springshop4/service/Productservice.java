package com.example.springshop4.service;

import com.example.springshop4.model.product;
import com.example.springshop4.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class Productservice {
    @Autowired
    ProductRepository productRepository;

    public List<product>getallProduct(){
        return productRepository.findAll();
    }

    public void addProduct(product product){
        productRepository.save(product);
    }

    public void removeproductbyid(long id){
        productRepository.deleteById(id);
    }

    public Optional<product>getproductbyid(long id){
        return productRepository.findById(id);
    }

    public List<product>getallproductsbyCategoryId(int id){
        return productRepository.findAllByCategoryId(id);
    }



}
