package com.example.springshop4.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class category {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="category_id")
    private int id;

    private String name;


}
