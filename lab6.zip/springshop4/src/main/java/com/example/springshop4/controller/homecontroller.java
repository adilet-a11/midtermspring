package com.example.springshop4.controller;


import com.example.springshop4.service.CategoryService;
import com.example.springshop4.service.Productservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class homecontroller {
    @Autowired
    CategoryService categoryService;

    @Autowired
    Productservice productservice;

    @GetMapping("/home")
    public String home(Model model){
        return "index";
    }


    @GetMapping("/shop")
    public String shop(Model model){
        model.addAttribute("categories",categoryService.getallcategory());
        model.addAttribute("products",productservice.getallProduct());
        return "shop";
    }

    @GetMapping("/shop/category/{id}")
    public String shopByCategory(Model model, @PathVariable int id){
        model.addAttribute("categories",categoryService.getallcategory());
        model.addAttribute("products",productservice.getallproductsbyCategoryId(id));
        return "shop";
    }

    @GetMapping("/shop/viewproduct/{id}")
    public String viewProduct(Model model, @PathVariable int id){

        model.addAttribute("product",productservice.getproductbyid(id).get());
        return "viewProduct";
    }
}
