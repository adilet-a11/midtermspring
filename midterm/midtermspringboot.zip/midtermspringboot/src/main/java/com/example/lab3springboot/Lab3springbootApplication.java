package com.example.lab3springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab3springbootApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab3springbootApplication.class, args);
    }

}
